// JavaScript Document
var loader = document.querySelector(".loader")
console.log(window.addEventListener("load", vanish));
function vanish() {
  loader.classList.add("disppear");
}